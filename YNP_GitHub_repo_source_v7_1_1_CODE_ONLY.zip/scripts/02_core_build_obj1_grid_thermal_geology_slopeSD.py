#!/usr/bin/env python3
# ============================================================
# OBJECTIVE 1 — CORE BUILD (SELF-CONTAINED, REVIEWER-READY)
#
# Reproduces the VERIFIED Obj-1 outputs used in the manuscript:
#  - 1 km grid clipped to AOI
#  - thermal area (m²) per cell
#  - geology richness (unique units) per cell  [field default: PTYPE_GEN]
#  - slope variability: SD of slope (degrees) from 30 m DEM
#  - normalization: min–max to [0,1] for each component
#  - composite: mean of normalized components (equal weights)
#  - hotspots: top 10% (>= p90) of composite index
#
# Outputs:
#  - processed_obj1/geodiversity_hotspots_obj1_slopeSD.gpkg (layer: obj1_grid_hotspots)
#  - processed_obj1/hotspot_summary_obj1_slopeSD.csv (per-cell table)
#
# Works if inputs are either:
#   A) /content/yell_data/processed/  (staged by 00_run_all_obj1.py), OR
#   B) in the same folder where this bundle was unzipped (root).
# ============================================================

import os, glob
from pathlib import Path
import numpy as np
import pandas as pd
import geopandas as gpd
import fiona
from shapely.geometry import box as shp_box

import rasterio
from rasterio.features import geometry_mask
from rasterio.enums import Resampling
from rasterio.transform import Affine
from rasterstats import zonal_stats


# ----------------------------
# Helpers
# ----------------------------
def find_first(patterns, roots):
    for root in roots:
        root = str(root)
        for pat in patterns:
            hits = glob.glob(os.path.join(root, "**", pat), recursive=True)
            if hits:
                hits = sorted(hits, key=lambda p: (len(p), p))
                return hits[0]
    return None

def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)
    return p

def minmax01(s: pd.Series) -> pd.Series:
    s = s.astype("float64")
    mn = float(np.nanmin(s.values)) if len(s) else 0.0
    mx = float(np.nanmax(s.values)) if len(s) else 0.0
    if np.isclose(mx - mn, 0.0):
        return pd.Series(np.zeros(len(s), dtype="float64"), index=s.index)
    return (s - mn) / (mx - mn)

def get_layer_name(gpkg_path: str, preferred: str):
    # Return preferred layer if present; else first layer.
    layers = list(fiona.listlayers(gpkg_path))
    if preferred in layers:
        return preferred
    return layers[0]


# ----------------------------
# Locate inputs
# ----------------------------
HERE = Path(__file__).resolve()
BUNDLE_ROOT = HERE.parents[1]                 # .../scripts/.. (bundle root)
STAGED_ROOT = Path("/content/yell_data/processed")

roots = [STAGED_ROOT, BUNDLE_ROOT, Path("/content"), Path.cwd()]

AOI_GPKG = find_first(["aoi_yell.gpkg", "YNP_codingearth_inputs_bundle.gpkg", "*aoi*.gpkg"], roots)
THERM_GPKG = find_first(["thermal_areas.gpkg"], roots)
GEO_GPKG = find_first(["geology_ofr99174.gpkg"], roots)
DEM_TIF = find_first(["dem_3dep_30m_utm12n.tif"], roots)

if not AOI_GPKG or not THERM_GPKG or not GEO_GPKG or not DEM_TIF:
    raise FileNotFoundError(
        "Missing one or more required inputs.\n"
        f"AOI_GPKG={AOI_GPKG}\nTHERM_GPKG={THERM_GPKG}\nGEO_GPKG={GEO_GPKG}\nDEM_TIF={DEM_TIF}\n"
        "Expected either staged inputs in /content/yell_data/processed or files present at bundle root."
    )

# Layer names
AOI_LAYER = get_layer_name(AOI_GPKG, "aoi")
THERM_LAYER = get_layer_name(THERM_GPKG, "thermal_areas")
GEO_LAYER = get_layer_name(GEO_GPKG, "geology")

print("AOI:", AOI_GPKG, "layer:", AOI_LAYER)
print("THERM:", THERM_GPKG, "layer:", THERM_LAYER)
print("GEO:", GEO_GPKG, "layer:", GEO_LAYER)
print("DEM:", DEM_TIF)

# ----------------------------
# Load vectors
# ----------------------------
aoi = gpd.read_file(AOI_GPKG, layer=AOI_LAYER)
thermal = gpd.read_file(THERM_GPKG, layer=THERM_LAYER)
geol = gpd.read_file(GEO_GPKG, layer=GEO_LAYER)

# Validate CRS and project to AOI CRS (expected UTM 12N)
target_crs = aoi.crs
if thermal.crs != target_crs:
    thermal = thermal.to_crs(target_crs)
if geol.crs != target_crs:
    geol = geol.to_crs(target_crs)

# Clean geometries
aoi = aoi[aoi.geometry.notnull()].copy()
thermal = thermal[thermal.geometry.notnull()].copy()
geol = geol[geol.geometry.notnull()].copy()
aoi["geometry"] = aoi.geometry.buffer(0)
thermal["geometry"] = thermal.geometry.buffer(0)
geol["geometry"] = geol.geometry.buffer(0)

aoi_union = aoi.union_all()

print("AOI features:", len(aoi))
print("Thermal features:", len(thermal))
print("Geology features:", len(geol))

# ----------------------------
# Build 1 km grid over AOI bbox
# ----------------------------
cell = 1000.0  # meters
minx, miny, maxx, maxy = aoi.total_bounds

xs = np.arange(np.floor(minx / cell) * cell, np.ceil(maxx / cell) * cell, cell)
ys = np.arange(np.floor(miny / cell) * cell, np.ceil(maxy / cell) * cell, cell)

polys = []
grid_id = 0
for x in xs:
    for y in ys:
        poly = shp_box(x, y, x + cell, y + cell)
        if poly.intersects(aoi_union):
            polys.append(poly)
        else:
            polys.append(None)

# Keep only intersecting cells
geoms = [p for p in polys if p is not None]
grid = gpd.GeoDataFrame({"grid_id": range(len(geoms))}, geometry=geoms, crs=target_crs)
print("Cells after AOI intersects:", len(grid))

# Clip grid to AOI boundary (keeps full cell geometry but ensures inside AOI for calculations via clip where needed)
grid_clip = gpd.overlay(grid, aoi, how="intersection")
grid_clip = grid_clip.drop(columns=[c for c in grid_clip.columns if c.startswith("id")], errors="ignore")
grid_clip = grid_clip.reset_index(drop=True)
grid_clip["grid_id"] = np.arange(len(grid_clip), dtype=int)
grid = grid_clip
print("Cells after AOI intersection geometry:", len(grid))

# ----------------------------
# Thermal area per cell (m²)
# ----------------------------
thermal["__t_area_m2"] = thermal.geometry.area
# Intersect thermal with grid; sum area
therm_ix = gpd.overlay(thermal[["__t_area_m2", "geometry"]], grid[["grid_id", "geometry"]], how="intersection")
therm_ix["ix_area_m2"] = therm_ix.geometry.area
therm_sum = therm_ix.groupby("grid_id")["ix_area_m2"].sum()
grid["thermal_area_m2"] = grid["grid_id"].map(therm_sum).fillna(0.0).astype("float64")

# ----------------------------
# Geology richness per cell (unique units)
# ----------------------------
unit_field_candidates = ["PTYPE_GEN", "UNIT", "UNIT_NAME", "MAP_UNIT", "UNIT_SYM", "UNIT_ABBR"]
unit_field = None
for c in unit_field_candidates:
    if c in geol.columns:
        unit_field = c
        break
if unit_field is None:
    # fall back to first non-geometry column
    unit_field = [c for c in geol.columns if c != "geometry"][0]
print("Using geology unit field:", unit_field)

# overlay intersection and count unique units per cell
geol_sub = geol[[unit_field, "geometry"]].copy()
geol_ix = gpd.overlay(geol_sub, grid[["grid_id", "geometry"]], how="intersection")

# Optional: sliver filtering (set env var MIN_GEO_IX_AREA_M2)
min_ix_area = float(os.environ.get("MIN_GEO_IX_AREA_M2", "0"))
if min_ix_area > 0:
    geol_ix["ix_area_m2"] = geol_ix.geometry.area
    geol_ix = geol_ix[geol_ix["ix_area_m2"] >= min_ix_area].copy()

rich = geol_ix.groupby("grid_id")[unit_field].nunique()
grid["geology_richness"] = grid["grid_id"].map(rich).fillna(0).astype(int)

# ----------------------------
# Slope SD (degrees) per cell from DEM
# ----------------------------
with rasterio.open(DEM_TIF) as src:
    dem = src.read(1, masked=True).astype("float64")
    dem_transform = src.transform
    dem_crs = src.crs

# Reproject AOI grid to DEM CRS if needed for zonal_stats raster alignment
grid_stats = grid.copy()
if grid_stats.crs != dem_crs:
    grid_stats = grid_stats.to_crs(dem_crs)

# Compute slope in degrees (Horn approximation via numpy gradients in projected units)
# Note: DEM in meters; transform gives pixel sizes
xres = abs(dem_transform.a)
yres = abs(dem_transform.e)
gy, gx = np.gradient(dem.filled(np.nan), yres, xres)
slope_rad = np.arctan(np.sqrt(gx**2 + gy**2))
slope_deg = np.degrees(slope_rad).astype("float32")

# Zonal std of slope
zs = zonal_stats(
    grid_stats.geometry,
    slope_deg,
    affine=dem_transform,
    stats=["std"],
    nodata=np.nan,
    all_touched=False
)
slope_sd = pd.Series([d.get("std", 0.0) if d else 0.0 for d in zs]).fillna(0.0).astype("float64")
grid_stats["slope_sd_deg"] = slope_sd.values

# Bring slope_sd back to grid CRS/order
grid["slope_sd_deg"] = grid_stats["slope_sd_deg"].values

# ----------------------------
# Normalize + composite + hotspots (MATCH VERIFIED OUTPUTS)
# ----------------------------
grid["n_thermal"] = minmax01(grid["thermal_area_m2"])
grid["n_geol"] = minmax01(grid["geology_richness"].astype("float64"))
grid["n_slopeSD"] = minmax01(grid["slope_sd_deg"])

grid["geodiv_index"] = (grid["n_thermal"] + grid["n_geol"] + grid["n_slopeSD"]) / 3.0

p90 = float(grid["geodiv_index"].quantile(0.90))
grid["hotspot_p90"] = (grid["geodiv_index"] >= p90).astype(int)

print("Hotspot threshold (p90):", p90)
print("Hotspot count:", int(grid["hotspot_p90"].sum()), "of", len(grid))

# ----------------------------
# Write outputs
# ----------------------------
# Choose a primary output directory.
# In Google Colab, /content is writable; in other environments it may not be.
def _writable_dir(p: Path) -> bool:
    try:
        p.mkdir(parents=True, exist_ok=True)
        test = p / ".write_test"
        test.write_text("ok")
        test.unlink()
        return True
    except Exception:
        return False

COLAB_OUT = Path("/content/yell_data/processed_obj1")
BUNDLE_OUT = BUNDLE_ROOT / "processed_obj1"

# Prefer Colab-style path if writable, else fall back to bundle root.
OUT_DIR = ensure_dir(COLAB_OUT) if _writable_dir(COLAB_OUT) else ensure_dir(BUNDLE_OUT)

# Always mirror to bundle root for zip portability (no-op if same).
ALT_OUT_DIR = ensure_dir(BUNDLE_OUT)

OUT_GPKG = OUT_DIR / "geodiversity_hotspots_obj1_slopeSD.gpkg"
OUT_CSV  = OUT_DIR / "hotspot_summary_obj1_slopeSD.csv"
OUT_LAYER = "obj1_grid_hotspots"

cols = ["grid_id","thermal_area_m2","geology_richness","slope_sd_deg","n_thermal","n_geol","n_slopeSD","geodiv_index","hotspot_p90","geometry"]
out_gdf = grid[cols].copy()

# Write to primary location
if OUT_GPKG.exists():
    OUT_GPKG.unlink()
out_gdf.to_file(OUT_GPKG, layer=OUT_LAYER, driver="GPKG")
out_gdf.drop(columns=["geometry"]).to_csv(OUT_CSV, index=False)

# Mirror to alt (bundle-root) location
ALT_GPKG = ALT_OUT_DIR / OUT_GPKG.name
ALT_CSV  = ALT_OUT_DIR / OUT_CSV.name
if ALT_GPKG.exists():
    ALT_GPKG.unlink()
out_gdf.to_file(ALT_GPKG, layer=OUT_LAYER, driver="GPKG")
out_gdf.drop(columns=["geometry"]).to_csv(ALT_CSV, index=False)

print("✅ Wrote:", OUT_GPKG)
print("✅ Wrote:", OUT_CSV)
print("✅ Also wrote:", ALT_GPKG)
print("✅ Also wrote:", ALT_CSV)

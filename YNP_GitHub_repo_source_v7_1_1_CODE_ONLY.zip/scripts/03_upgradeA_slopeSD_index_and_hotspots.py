# ============================================================
# OBJECTIVE 1 (UPGRADE A) — Replace elevation range with SLOPE VARIABILITY
# Terrain component becomes: slope_sd_deg (std. dev. of slope in degrees)
# Optional: TRI (terrain ruggedness index) as mean abs diff to 8 neighbors
#
# Inputs (must already exist):
#   /content/yell_data/processed/geodiversity_hotspots_obj1.gpkg  (layer: geodiversity_grid)
#   /content/yell_data/processed/dem_3dep_30m_utm12n.tif
#
# Outputs:
#   /content/yell_data/processed/geodiversity_hotspots_obj1_slopeSD.gpkg (layer: geodiversity_grid_slopeSD)
#   /content/yell_data/processed/hotspot_summary_obj1_slopeSD.csv
# ============================================================

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterstats import zonal_stats
from pathlib import Path

GRID_GPKG = "/content/yell_data/processed/geodiversity_hotspots_obj1.gpkg"
GRID_LAYER = "geodiversity_grid"
DEM_TIF = "/content/yell_data/processed/dem_3dep_30m_utm12n.tif"

OUT_GPKG = "/content/yell_data/processed/geodiversity_hotspots_obj1_slopeSD.gpkg"
OUT_LAYER = "geodiversity_grid_slopeSD"
OUT_CSV = "/content/yell_data/processed/hotspot_summary_obj1_slopeSD.csv"

gdf = gpd.read_file(GRID_GPKG, layer=GRID_LAYER)
required = {"cell_id", "thermal_area_m2", "geology_richness", "geometry"}
missing = required - set(gdf.columns)
if missing:
    raise KeyError(f"Missing required columns in grid: {missing}")

with rasterio.open(DEM_TIF) as src:
    dem = src.read(1).astype("float32")
    dem_nodata = src.nodata
    transform = src.transform
    dem_crs = src.crs

if dem_nodata is not None:
    dem = np.where(dem == dem_nodata, np.nan, dem)

xres = abs(transform.a)
yres = abs(transform.e)

dz_dy, dz_dx = np.gradient(dem, yres, xres)
slope_rad = np.arctan(np.sqrt(dz_dx**2 + dz_dy**2))
slope_deg = np.degrees(slope_rad).astype("float32")
slope_deg[~np.isfinite(dem)] = np.nan

print("DEM CRS:", dem_crs, "DEM shape:", dem.shape, "pixel:", (xres, yres))
print("Slope deg stats (finite):", np.nanmin(slope_deg), np.nanmedian(slope_deg), np.nanmax(slope_deg))

def compute_tri_mean_absdiff_8n(dem_arr):
    H, W = dem_arr.shape
    pad = np.pad(dem_arr, 1, mode="constant", constant_values=np.nan)
    center = pad[1:1+H, 1:1+W]
    neigh_offsets = [(-1,-1), (-1,0), (-1,1),
                     (0,-1),          (0,1),
                     (1,-1),  (1,0),  (1,1)]
    diffs = []
    for dy, dx in neigh_offsets:
        neigh = pad[1+dy:1+dy+H, 1+dx:1+dx+W]
        diffs.append(np.abs(center - neigh))
    tri = np.nanmean(np.stack(diffs, axis=0), axis=0).astype("float32")
    tri[~np.isfinite(center)] = np.nan
    return tri

tri = compute_tri_mean_absdiff_8n(dem)
print("TRI stats (finite):", np.nanmin(tri), np.nanmedian(tri), np.nanmax(tri))

if gdf.crs is None:
    raise ValueError("Grid CRS is None. Set CRS first.")
if str(gdf.crs) != str(dem_crs):
    print("[warn] Grid CRS != DEM CRS. Reprojecting grid to DEM CRS for zonal stats.")
    gdf = gdf.to_crs(dem_crs)

slope_stats = zonal_stats(
    gdf.geometry, slope_deg, affine=transform,
    stats=["mean", "std"], nodata=np.nan, all_touched=False
)
slope_df = pd.DataFrame(slope_stats).rename(columns={"mean":"slope_mean_deg", "std":"slope_sd_deg"})

tri_stats = zonal_stats(
    gdf.geometry, tri, affine=transform,
    stats=["mean"], nodata=np.nan, all_touched=False
)
tri_df = pd.DataFrame(tri_stats).rename(columns={"mean":"tri_mean_m"})

gdf["slope_mean_deg"] = slope_df["slope_mean_deg"].fillna(0.0)
gdf["slope_sd_deg"]   = slope_df["slope_sd_deg"].fillna(0.0)
gdf["tri_mean_m"]     = tri_df["tri_mean_m"].fillna(0.0)

print("Slope SD summary:", gdf["slope_sd_deg"].describe())
print("TRI mean summary:", gdf["tri_mean_m"].describe())

def zscore(series):
    s = series.astype(float)
    sd = s.std()
    if sd == 0 or np.isnan(sd):
        return pd.Series(np.zeros(len(s)), index=s.index)
    return (s - s.mean()) / sd

gdf["z_geology"] = zscore(gdf["geology_richness"])
gdf["z_slopeSD"] = zscore(gdf["slope_sd_deg"])

gdf["thermal_log1p"] = np.log1p(gdf["thermal_area_m2"].astype(float))
gdf["z_thermal_raw"] = zscore(gdf["thermal_area_m2"])
gdf["z_thermal_log"] = zscore(gdf["thermal_log1p"])

gdf["geodiv_index_slopeSD_rawThermal"] = gdf["z_thermal_raw"] + gdf["z_geology"] + gdf["z_slopeSD"]
gdf["geodiv_index_slopeSD_logThermal"] = gdf["z_thermal_log"] + gdf["z_geology"] + gdf["z_slopeSD"]

p90_raw = gdf["geodiv_index_slopeSD_rawThermal"].quantile(0.90)
p90_log = gdf["geodiv_index_slopeSD_logThermal"].quantile(0.90)
gdf["hotspot_p90_slopeSD_rawThermal"] = (gdf["geodiv_index_slopeSD_rawThermal"] >= p90_raw).astype(int)
gdf["hotspot_p90_slopeSD_logThermal"] = (gdf["geodiv_index_slopeSD_logThermal"] >= p90_log).astype(int)

print("\n--- NEW HOTSPOTS (Slope SD terrain) ---")
print("p90 (raw thermal):", float(p90_raw), "hotspot cells:", int(gdf["hotspot_p90_slopeSD_rawThermal"].sum()))
print("p90 (log thermal):", float(p90_log), "hotspot cells:", int(gdf["hotspot_p90_slopeSD_logThermal"].sum()))

def jaccard(a, b):
    a = a.astype(bool); b = b.astype(bool)
    inter = (a & b).sum()
    union = (a | b).sum()
    return float(inter / union) if union else np.nan

if "hotspot_p90" in gdf.columns:
    jac_raw = jaccard(gdf["hotspot_p90"], gdf["hotspot_p90_slopeSD_rawThermal"])
    jac_log = jaccard(gdf["hotspot_p90"], gdf["hotspot_p90_slopeSD_logThermal"])
    print("\n--- JACCARD overlap vs original hotspot_p90 ---")
    print("Jaccard (slopeSD + raw thermal) :", jac_raw)
    print("Jaccard (slopeSD + log thermal) :", jac_log)
else:
    print("\n[info] original 'hotspot_p90' not found; skipping overlap.")

def summarize(df, label):
    return pd.Series({
        "group": label,
        "n_cells": len(df),
        "mean_index": df["geodiv_index_slopeSD_rawThermal"].mean(),
        "mean_thermal_area_m2": df["thermal_area_m2"].mean(),
        "mean_geology_richness": df["geology_richness"].mean(),
        "mean_slope_sd_deg": df["slope_sd_deg"].mean(),
        "median_index": df["geodiv_index_slopeSD_rawThermal"].median(),
    })

summary = pd.concat([
    summarize(gdf[gdf["hotspot_p90_slopeSD_rawThermal"]==1], "hotspot_p90_slopeSD"),
    summarize(gdf[gdf["hotspot_p90_slopeSD_rawThermal"]==0], "non_hotspot")
], axis=1).T

summary.to_csv(OUT_CSV, index=False)
print("✔ Summary saved:", OUT_CSV)
print(summary)

out_path = Path(OUT_GPKG)
if out_path.exists():
    out_path.unlink()
gdf.to_file(OUT_GPKG, layer=OUT_LAYER, driver="GPKG")
print("✔ Saved upgraded grid:", OUT_GPKG, "layer:", OUT_LAYER)

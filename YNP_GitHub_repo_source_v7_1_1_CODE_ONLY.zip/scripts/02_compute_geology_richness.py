# ============================================================
# Objective 1 — Compute GEOLOGY RICHNESS per 1-km grid cell
# geology_richness = number of unique geology units per cell
#
# Inputs:
#   /content/yell_data/processed/geodiversity_grid_1km.gpkg (or your grid gpkg)
#   /content/yell_data/processed/geology_ofr99174.gpkg
#
# Output:
#   new gpkg with geology_richness added/updated
# ============================================================

import geopandas as gpd
import pandas as pd
from pathlib import Path

GRID_GPKG   = "/content/yell_data/processed/geodiversity_hotspots_obj1.gpkg"
GRID_LAYER  = "geodiversity_grid"

GEO_GPKG    = "/content/yell_data/processed/geology_ofr99174.gpkg"
GEO_LAYER   = "geology"

OUT_GPKG    = "/content/yell_data/processed/geodiversity_hotspots_obj1_with_geology_richness.gpkg"
OUT_LAYER   = "geodiversity_grid"

METHOD = "overlay"            # "sjoin" or "overlay"
MIN_INTERSECT_AREA_M2 = 10000 # sliver filter for overlay; set 0 to disable

grid = gpd.read_file(GRID_GPKG, layer=GRID_LAYER)
geol = gpd.read_file(GEO_GPKG, layer=GEO_LAYER)

if grid.crs is None:
    raise ValueError("Grid CRS is None.")
if geol.crs is None:
    raise ValueError("Geology CRS is None.")

if grid.crs != geol.crs:
    geol = geol.to_crs(grid.crs)

unit_candidates = ["PTYPE_GEN", "PTYPE", "SYMB"]
unit_field = next((c for c in unit_candidates if c in geol.columns), None)
if unit_field is None:
    raise KeyError(f"No geology unit field found. Tried {unit_candidates}.")

grid_min = grid[["cell_id", "geometry"]].copy()
geol_min = geol[[unit_field, "geometry"]].dropna(subset=[unit_field, "geometry"]).copy()

grid_min["geometry"] = grid_min.geometry.buffer(0)
geol_min["geometry"] = geol_min.geometry.buffer(0)

if METHOD.lower() == "sjoin":
    joined = gpd.sjoin(grid_min, geol_min, predicate="intersects", how="left")
    richness = joined.groupby("cell_id")[unit_field].nunique(dropna=True).rename("geology_richness")
elif METHOD.lower() == "overlay":
    inter = gpd.overlay(grid_min, geol_min, how="intersection", keep_geom_type=False)
    if len(inter) == 0:
        richness = pd.Series(0, index=grid_min["cell_id"].unique(), name="geology_richness")
    else:
        inter["intersect_area_m2"] = inter.geometry.area
        if MIN_INTERSECT_AREA_M2 and MIN_INTERSECT_AREA_M2 > 0:
            inter = inter[inter["intersect_area_m2"] >= MIN_INTERSECT_AREA_M2].copy()
        richness = inter.groupby("cell_id")[unit_field].nunique(dropna=True).rename("geology_richness")
else:
    raise ValueError("METHOD must be 'sjoin' or 'overlay'")

grid_out = grid.copy()
grid_out = grid_out.merge(richness.reset_index(), on="cell_id", how="left")
grid_out["geology_richness"] = grid_out["geology_richness"].fillna(0).astype(int)

out_path = Path(OUT_GPKG)
if out_path.exists():
    out_path.unlink()

grid_out.to_file(OUT_GPKG, layer=OUT_LAYER, driver="GPKG")
print("✅ Done. Unit field used:", unit_field)
print("Saved:", OUT_GPKG)

#!/usr/bin/env python3
# ============================================================
# Objective 1 — FAST BUILDER (optional)
# Creates the same Obj1 outputs as the core build, but uses
# a window-based slope SD computation (faster than zonal_stats).
#
# Outputs (in bundle-root/processed_obj1):
#  - geodiversity_hotspots_obj1_slopeSD.gpkg (layer: obj1_grid_hotspots)
#  - hotspot_summary_obj1_slopeSD.csv
#  - obj1_cells_with_centroids_wgs84.csv
#  - obj1_hotspot_p90_summary.csv
# ============================================================

import os, glob
from pathlib import Path
import numpy as np
import pandas as pd
import geopandas as gpd
import fiona
from shapely.geometry import box
from shapely.ops import unary_union
from shapely.geometry import mapping

import rasterio
from rasterio.windows import from_bounds, transform as window_transform
from rasterio.features import geometry_mask


def find_first(patterns, roots):
    for root in roots:
        root = str(root)
        for pat in patterns:
            hits = glob.glob(os.path.join(root, "**", pat), recursive=True)
            if hits:
                hits = sorted(hits, key=lambda p: (len(p), p))
                return hits[0]
    return None

def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)
    return p

def minmax01(s: pd.Series) -> pd.Series:
    s = s.astype("float64")
    mn = float(np.nanmin(s.values)) if len(s) else 0.0
    mx = float(np.nanmax(s.values)) if len(s) else 0.0
    if np.isclose(mx - mn, 0.0):
        return pd.Series(np.zeros(len(s), dtype="float64"), index=s.index)
    return (s - mn) / (mx - mn)

def get_layer_name(gpkg_path: str, preferred: str):
    layers = list(fiona.listlayers(gpkg_path))
    if preferred in layers:
        return preferred
    return layers[0]


HERE = Path(__file__).resolve()
BUNDLE_ROOT = HERE.parents[1]
STAGED_ROOT = Path("/content/yell_data/processed")
roots = [STAGED_ROOT, BUNDLE_ROOT, Path.cwd()]

AOI_GPKG = find_first(["aoi_yell.gpkg"], roots)
THERM_GPKG = find_first(["thermal_areas.gpkg"], roots)
GEO_GPKG = find_first(["geology_ofr99174.gpkg"], roots)
DEM_TIF = find_first(["dem_3dep_30m_utm12n.tif", "dem_*.tif"], roots)

if not all([AOI_GPKG, THERM_GPKG, GEO_GPKG, DEM_TIF]):
    raise FileNotFoundError("Missing one or more required inputs (AOI/thermal/geology/DEM).")

AOI_LAYER = get_layer_name(AOI_GPKG, "aoi")
THERM_LAYER = get_layer_name(THERM_GPKG, "thermal_areas")
GEO_LAYER = get_layer_name(GEO_GPKG, "geology")

aoi = gpd.read_file(AOI_GPKG, layer=AOI_LAYER)
thermal = gpd.read_file(THERM_GPKG, layer=THERM_LAYER)
geol = gpd.read_file(GEO_GPKG, layer=GEO_LAYER)

target_crs = aoi.crs
thermal = thermal.to_crs(target_crs)
geol = geol.to_crs(target_crs)

aoi_union = unary_union(aoi.geometry)

# ----------------------------
# Build 1 km grid over AOI bbox (same as core build)
# ----------------------------
cell = 1000.0
minx, miny, maxx, maxy = aoi.total_bounds
xs = np.arange(np.floor(minx / cell) * cell, np.ceil(maxx / cell) * cell, cell)
ys = np.arange(np.floor(miny / cell) * cell, np.ceil(maxy / cell) * cell, cell)

geoms = []
for x in xs:
    for y in ys:
        poly = box(x, y, x + cell, y + cell)
        if poly.intersects(aoi_union):
            geoms.append(poly)

grid = gpd.GeoDataFrame({"grid_id": range(len(geoms))}, geometry=geoms, crs=target_crs)

# Clip grid to AOI boundary (same as core build)
grid_clip = gpd.overlay(grid, aoi, how="intersection")
grid_clip = grid_clip.reset_index(drop=True)
grid_clip["grid_id"] = np.arange(len(grid_clip), dtype=int)
grid = grid_clip[["grid_id", "geometry"]]

# ----------------------------
# Thermal area per cell (m²) (uses overlay, like core build)
# ----------------------------
thermal["__t_area_m2"] = thermal.geometry.area
therm_ix = gpd.overlay(thermal[["__t_area_m2", "geometry"]], grid[["grid_id", "geometry"]], how="intersection")
therm_ix["ix_area_m2"] = therm_ix.geometry.area
therm_sum = therm_ix.groupby("grid_id")["ix_area_m2"].sum()
grid["thermal_area_m2"] = grid["grid_id"].map(therm_sum).fillna(0.0).astype("float64")

# ----------------------------
# Geology richness per cell (unique units) (FAST: sjoin)
# ----------------------------
unit_field_candidates = ["PTYPE_GEN", "UNIT", "UNIT_NAME", "MAP_UNIT", "UNIT_SYM", "UNIT_ABBR"]
unit_field = None
for c in unit_field_candidates:
    if c in geol.columns:
        unit_field = c
        break
if unit_field is None:
    unit_field = [c for c in geol.columns if c != "geometry"][0]

# Spatial join (intersects) and count unique units per cell
join = gpd.sjoin(grid[["grid_id", "geometry"]], geol[[unit_field, "geometry"]], how="left", predicate="intersects")
rich = join.groupby("grid_id")[unit_field].nunique()
grid["geology_richness"] = grid["grid_id"].map(rich).fillna(0).astype(int)

# ----------------------------
# Slope SD (degrees) per cell from DEM (FAST window-based)
# ----------------------------
with rasterio.open(DEM_TIF) as src:
    dem = src.read(1, masked=True).astype("float64")
    dem_transform = src.transform
    dem_crs = src.crs

# Reproject grid to DEM CRS if needed
grid_stats = grid.copy()
if grid_stats.crs != dem_crs:
    grid_stats = grid_stats.to_crs(dem_crs)

xres = abs(dem_transform.a)
yres = abs(dem_transform.e)
gy, gx = np.gradient(dem.filled(np.nan), yres, xres)
slope_rad = np.arctan(np.sqrt(gx**2 + gy**2))
slope_deg = np.degrees(slope_rad).astype("float32")

# Determine which cells are full 1km^2 (avoid masking cost)
full_area = cell * cell
areas = grid_stats.geometry.area.values
is_full = areas >= (0.999 * full_area)

slope_sd = np.zeros(len(grid_stats), dtype="float64")

with rasterio.open(DEM_TIF) as src:
    for i, geom in enumerate(grid_stats.geometry.values):
        if geom is None or geom.is_empty:
            continue
        minx, miny, maxx, maxy = geom.bounds
        win = from_bounds(minx, miny, maxx, maxy, transform=src.transform)
        # Clamp window
        win = win.round_offsets().round_lengths()
        if win.width <= 0 or win.height <= 0:
            continue

        r0, c0 = int(win.row_off), int(win.col_off)
        r1 = r0 + int(win.height)
        c1 = c0 + int(win.width)
        sub = slope_deg[r0:r1, c0:c1]

        if is_full[i]:
            slope_sd[i] = float(np.nanstd(sub))
        else:
            w_transform = window_transform(win, src.transform)
            mask = geometry_mask([mapping(geom)], out_shape=sub.shape, transform=w_transform, invert=True, all_touched=False)
            vals = sub[mask]
            slope_sd[i] = float(np.nanstd(vals)) if vals.size else 0.0

grid_stats["slope_sd_deg"] = slope_sd

# Bring slope_sd back to grid CRS/order
grid["slope_sd_deg"] = grid_stats["slope_sd_deg"].values

# ----------------------------
# Normalize + composite + hotspots (same as core build)
# ----------------------------
grid["n_thermal"] = minmax01(grid["thermal_area_m2"])
grid["n_geol"] = minmax01(grid["geology_richness"].astype("float64"))
grid["n_slopeSD"] = minmax01(grid["slope_sd_deg"])

grid["geodiv_index"] = (grid["n_thermal"] + grid["n_geol"] + grid["n_slopeSD"]) / 3.0

p90 = float(grid["geodiv_index"].quantile(0.90))
grid["hotspot_p90"] = (grid["geodiv_index"] >= p90).astype(int)

# ----------------------------
# Write outputs (bundle-root/processed_obj1)
# ----------------------------
OUT_DIR = ensure_dir(BUNDLE_ROOT / "processed_obj1")
OUT_GPKG = OUT_DIR / "geodiversity_hotspots_obj1_slopeSD.gpkg"
OUT_CSV  = OUT_DIR / "hotspot_summary_obj1_slopeSD.csv"
OUT_LAYER = "obj1_grid_hotspots"

cols = ["grid_id","thermal_area_m2","geology_richness","slope_sd_deg","n_thermal","n_geol","n_slopeSD","geodiv_index","hotspot_p90","geometry"]
out_gdf = gpd.GeoDataFrame(grid[cols].copy(), geometry="geometry", crs=grid.crs)

if OUT_GPKG.exists():
    OUT_GPKG.unlink()
out_gdf.to_file(OUT_GPKG, layer=OUT_LAYER, driver="GPKG")
out_gdf.drop(columns=["geometry"]).to_csv(OUT_CSV, index=False)

# Centroids (WGS84)
cent = out_gdf.geometry.centroid
cent_wgs84 = gpd.GeoSeries(cent, crs=out_gdf.crs).to_crs(4326)
cent_df = out_gdf.drop(columns=["geometry"]).copy()
cent_df["centroid_lon"] = cent_wgs84.x.values
cent_df["centroid_lat"] = cent_wgs84.y.values
cent_path = OUT_DIR / "obj1_cells_with_centroids_wgs84.csv"
cent_df.to_csv(cent_path, index=False)

# Summary
summary_path = OUT_DIR / "obj1_hotspot_p90_summary.csv"
pd.DataFrame([{
    "p90_threshold_geodiv_index": p90,
    "hotspot_count": int(out_gdf["hotspot_p90"].sum()),
    "grid_cells_total": int(len(out_gdf)),
    "hotspot_share": float(out_gdf["hotspot_p90"].mean())
}]).to_csv(summary_path, index=False)

print("Hotspot threshold (p90):", p90)
print("Hotspot count:", int(out_gdf["hotspot_p90"].sum()), "of", len(out_gdf))
print("✅ Wrote:", OUT_GPKG)
print("✅ Wrote:", OUT_CSV)
print("✅ Wrote:", cent_path)
print("✅ Wrote:", summary_path)

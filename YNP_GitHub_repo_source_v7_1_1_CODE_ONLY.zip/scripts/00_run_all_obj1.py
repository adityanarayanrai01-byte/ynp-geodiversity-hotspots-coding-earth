#!/usr/bin/env python3
# ============================================================
# ONE-CLICK RUNNER — Objective 1 (Coding Earth) Yellowstone
#
# Reviewer-safe (no internet required):
#  - Stages the bundled input files into /content/yell_data/processed
#  - Runs the core Obj-1 build (1 km grid + thermal/geology/slopeSD + composite + hotspots)
#  - Generates Fig1 with scale bar + legend OUTSIDE map area
#  - Bundles outputs + scripts + docs into a single ZIP
#
# Usage (Colab):
#   1) Upload and unzip the reviewers bundle, e.g. into /content/ynp_obj1_bundle
#   2) Run:
#        !python /content/ynp_obj1_bundle/scripts/00_run_all_obj1.py
#
# Optional:
#   --no-install     Skip pip installs
#   --skip-maps      Skip figure generation
#   --bundle-only    Only create the reviewer output bundle zip (assumes outputs exist)
# ============================================================

import os, sys, shutil, zipfile, argparse, subprocess
from pathlib import Path
from datetime import datetime, timezone

def run(cmd):
    print("\n▶", " ".join(map(str, cmd)))
    subprocess.check_call(cmd)

def pip_install(pkgs):
    run([sys.executable, "-m", "pip", "-q", "install"] + pkgs)

def zip_dir(src_dir: Path, zip_path: Path, exclude=()):
    src_dir = Path(src_dir)
    zip_path = Path(zip_path)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in src_dir.rglob("*"):
            if p.is_dir():
                continue
            rel = p.relative_to(src_dir)
            rel_s = str(rel)
            if any(rel_s.startswith(e) for e in exclude):
                continue
            z.write(p, arcname=str(rel))

def stage_inputs(bundle_root: Path, staged_processed: Path):
    staged_processed.mkdir(parents=True, exist_ok=True)

    needed = [
        ("aoi_yell.gpkg",),
        ("thermal_areas.gpkg",),
        ("geology_ofr99174.gpkg",),
        ("dem_3dep_30m_utm12n.tif",),
        # optional but included:
        ("YNP_codingearth_inputs_bundle.gpkg",),
        ("gnis_geonames.gpkg",),
        ("gnis_geonames_clean.gpkg",),
        ("sources_manifest.json",),
        ("sources_manifest_with_scripts.json",),
    ]

    for names in needed:
        # copy first match if present at bundle root
        for nm in names:
            src = bundle_root / nm
            if src.exists():
                dst = staged_processed / nm
                if not dst.exists() or src.stat().st_size != dst.stat().st_size:
                    shutil.copy2(src, dst)
                break

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-install", action="store_true")
    ap.add_argument("--skip-maps", action="store_true")
    ap.add_argument("--bundle-only", action="store_true")
    args = ap.parse_args()

    bundle_root = Path(__file__).resolve().parents[1]
    scripts = bundle_root / "scripts"
    docs = bundle_root / "docs"

    # Staged locations (standard)
    root = Path("/content/yell_data")
    processed = root / "processed"
    out_obj1 = root / "processed_obj1"

    if not args.no_install:
        pip_install([
            "geopandas", "pyogrio", "shapely", "pyproj", "fiona",
            "rasterio", "rasterstats", "numpy", "pandas",
            "matplotlib", "tqdm"
        ])

    s_core = scripts / "02_core_build_obj1_grid_thermal_geology_slopeSD.py"
    s_maps = scripts / "04_make_fig1_maps_scalebar_outside.py"

    if not args.bundle_only:
        # Stage bundled inputs (no internet)
        stage_inputs(bundle_root, processed)

        # Run core build
        run([sys.executable, str(s_core)])

        # Make figure (optional)
        if not args.skip_maps:
            run([sys.executable, str(s_maps)])

    # Bundle outputs + scripts + docs
    bundle_zip = bundle_root / "Objective1_PlugNPlay_OutputBundle.zip"
    tmp = bundle_root / "_bundle_tmp"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True, exist_ok=True)

    if out_obj1.exists():
        shutil.copytree(out_obj1, tmp / "processed_obj1", dirs_exist_ok=True)

    # include staged inputs (so reviewers can re-run without re-uploading)
    if processed.exists():
        shutil.copytree(processed, tmp / "processed_inputs", dirs_exist_ok=True)

    if scripts.exists():
        shutil.copytree(scripts, tmp / "scripts", dirs_exist_ok=True)
    if docs.exists():
        shutil.copytree(docs, tmp / "docs", dirs_exist_ok=True)

    run_manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "bundle_root": str(bundle_root),
        "notes": "Objective-1 output bundle (no-internet runner)."
    }
    (tmp / "run_manifest.json").write_text(__import__("json").dumps(run_manifest, indent=2))

    zip_dir(tmp, bundle_zip, exclude=("__pycache__", ".ipynb_checkpoints"))
    shutil.rmtree(tmp)

    print("\n✔ Output bundle created:", bundle_zip)
    print("Colab download:")
    print('  from google.colab import files; files.download("' + str(bundle_zip) + '")')

if __name__ == "__main__":
    main()

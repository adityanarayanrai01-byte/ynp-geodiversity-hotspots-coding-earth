#!/usr/bin/env python3
# NOTE: This file is kept for backward compatibility.
# The publication figure is now Figure 1 (not Figure 2).
from pathlib import Path
import runpy

here = Path(__file__).resolve().parent
target = here / "04_make_fig1_maps_scalebar_outside.py"
runpy.run_path(str(target), run_name="__main__")

# ============================================================
# CODING EARTH — Yellowstone data procurement (AOI, thermal, DEM, GNIS, geology)
#
# Goal:
#   Produce a clean, reviewer-ready "inputs" bundle for Objective 1:
#     - AOI boundary (Yellowstone)
#     - Thermal polygons (ScienceBase)
#     - Geology polygons (USGS OFR 99-174)
#     - GNIS / National Map gazetteer points (ArcGIS REST)
#     - DEM (USGS 3DEP via py3dep)
#
# Outputs (default):
#   /content/yell_data/processed/aoi_yell.gpkg
#   /content/yell_data/processed/thermal_areas.gpkg
#   /content/yell_data/processed/geology_ofr99174.gpkg
#   /content/yell_data/processed/gnis_geonames.gpkg
#   /content/yell_data/processed/dem_3dep_30m_utm12n.tif
#   /content/yell_data/processed/sources_manifest.json
#
# Notes:
# - Robust downloads (retries + resume)
# - CRS handling:
#     AOI target CRS: EPSG:26912 (NAD83 / UTM 12N)
#     py3dep DEM often returns EPSG:5070; we clip in DEM CRS then reproject to 26912.
# - GNIS: auto-discovers point/multipoint sublayers from the MapServer, then queries by bbox.
#
# Tested pattern: run in Colab.
# ============================================================

# ----------------------------
# (Optional) Cell: install deps in Colab
# ----------------------------
# !pip -q install geopandas shapely pyproj fiona rasterio rioxarray tqdm requests py3dep xarray netcdf4

import re, json, time, zipfile, glob
from pathlib import Path
from datetime import datetime, timezone

import pandas as pd
import geopandas as gpd
import requests
from tqdm import tqdm
import rioxarray as rxr

from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ----------------------------
# Parameters
# ----------------------------
# ----------------------------
# Runtime options (procurement is optional)
# ----------------------------
import argparse

def _has_internet(timeout=5):
    try:
        r = requests.get('https://www.google.com/generate_204', timeout=timeout)
        return r.status_code in (200, 204)
    except Exception:
        try:
            r = requests.get('https://example.com', timeout=timeout)
            return r.status_code == 200
        except Exception:
            return False

parser = argparse.ArgumentParser(add_help=True)
parser.add_argument('--out_root', default='/content/yell_data', help='Output root folder (default: /content/yell_data)')
parser.add_argument('--dry_run', action='store_true', help='Print planned actions/paths and exit')
parser.add_argument('--skip_if_exists', action='store_true', help='If expected outputs already exist, do nothing and exit (recommended)')
parser.add_argument('--require_internet', action='store_true', help='Fail if internet is not available (default: do not fail if outputs exist)')
args, _unknown = parser.parse_known_args()

ROOT = Path(args.out_root)
RAW  = ROOT / "raw"
PROC = ROOT / "processed"
TMP  = ROOT / "tmp"
for d in (RAW, PROC, TMP):
    d.mkdir(parents=True, exist_ok=True)

# AOI (Yellowstone boundary/tracts)
AOI_ZIP_URL   = "https://irma.nps.gov/DataStore/DownloadFile/754059?Reference=2316784"
AOI_ZIP_LOCAL = Path("/content/nps_yell_tracts.zip")  # if present, use it

# Thermal polygons (ScienceBase item)
SCIENCEBASE_ITEM_ID = "661d5eb7d34e7eb9eb7e3a41"

# Geology (USGS OFR 99-174)
GEOLOGY_ZIP_URL = "https://pubs.usgs.gov/of/1999/ofr-99-0174/ofr99174.zip"

# GNIS / National Map Gazetteer (ArcGIS REST)
GEONAMES_SERVICE = "https://carto.nationalmap.gov/arcgis/rest/services/geonames/MapServer"

# DEM (USGS 3DEP via py3dep)
DEM_RES_M = 30
AOI_TARGET_EPSG = 26912  # NAD83 / UTM zone 12N

# Outputs
AOI_GPKG      = PROC / "aoi_yell.gpkg"
THERMAL_GPKG  = PROC / "thermal_areas.gpkg"
GEOLOGY_GPKG  = PROC / "geology_ofr99174.gpkg"
GNIS_GPKG     = PROC / "gnis_geonames.gpkg"
DEM_TIF       = PROC / f"dem_3dep_{DEM_RES_M}m_utm12n.tif"

# --- Optional safety: procurement is NOT required to reproduce this paper.
# --- If bundled outputs already exist (common in reviewer ZIP), skip downloads.
expected_outputs = [AOI_GPKG, THERMAL_GPKG, GEOLOGY_GPKG, GNIS_GPKG, DEM_TIF]
if args.dry_run:
    print('DRY RUN — would write outputs to:')
    for p in expected_outputs:
        print(' -', p)
    print('Internet available:', _has_internet())
    raise SystemExit(0)

if args.skip_if_exists and all(p.exists() for p in expected_outputs):
    print('All expected procurement outputs already exist — skipping procurement.')
    print('Tip: Reproduction does not require procurement; run scripts/00_run_all_obj1.py instead.')
    raise SystemExit(0)

if not _has_internet():
    msg = ('No internet detected. Procurement requires internet and is OPTIONAL. '
           'If you are reviewing this paper, use the bundled inputs and run scripts/00_run_all_obj1.py.')
    print(msg)
    if args.require_internet:
        raise SystemExit(2)
    # If outputs do not exist, exit with a clear message rather than failing mid-download.
    if not all(p.exists() for p in expected_outputs):
        raise SystemExit(2)

MANIFEST_JSON = PROC / "sources_manifest.json"

# ----------------------------
# Robust requests session
# ----------------------------
def make_session():
    s = requests.Session()
    retries = Retry(
        total=8,
        backoff_factor=1.2,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET", "HEAD"])
    )
    s.mount("https://", HTTPAdapter(max_retries=retries))
    s.mount("http://",  HTTPAdapter(max_retries=retries))
    s.headers.update({"User-Agent": "coding-earth-ynp-procure/1.2"})
    return s

SESSION = make_session()

def download_with_resume(url: str, out_path: Path, chunk=1024*1024, max_tries=6):
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    remote_size = None
    try:
        h = SESSION.head(url, allow_redirects=True, timeout=60)
        if h.ok and h.headers.get("Content-Length"):
            remote_size = int(h.headers["Content-Length"])
    except Exception:
        pass

    existing = out_path.stat().st_size if out_path.exists() else 0
    if remote_size is not None and existing >= remote_size and remote_size > 0:
        print(f"✔ cached: {out_path.name}")
        return out_path

    mode = "ab" if existing > 0 else "wb"

    for attempt in range(1, max_tries + 1):
        try:
            headers = {}
            if existing > 0:
                headers["Range"] = f"bytes={existing}-"

            with SESSION.get(url, stream=True, allow_redirects=True, headers=headers, timeout=120) as r:
                r.raise_for_status()

                total = remote_size
                if total is None:
                    cr = r.headers.get("Content-Range")
                    if cr and "/" in cr:
                        total = int(cr.split("/")[-1])

                pbar = tqdm(
                    total=total, initial=existing, unit="B", unit_scale=True,
                    desc=f"downloading {out_path.name}", leave=True
                )
                with open(out_path, mode) as f:
                    for part in r.iter_content(chunk_size=chunk):
                        if part:
                            f.write(part)
                            existing += len(part)
                            pbar.update(len(part))
                pbar.close()

            if remote_size is not None and existing < remote_size:
                raise IOError(f"Incomplete download: {existing} < {remote_size}")
            return out_path

        except Exception as e:
            if attempt == max_tries:
                raise
            wait = 2 ** attempt
            print(f"[warn] download failed (attempt {attempt}/{max_tries}): {type(e).__name__}: {e}")
            print(f"       retrying in {wait}s …")
            time.sleep(wait)
            mode = "ab"
            existing = out_path.stat().st_size if out_path.exists() else 0

def unzip(zip_path: Path, out_dir: Path):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(out_dir)
    return out_dir

def find_shapefiles(folder: Path):
    return sorted([Path(p) for p in glob.glob(str(Path(folder) / "**" / "*.shp"), recursive=True)])

def pick_best_polygon_shp(shps):
    best, best_n = None, -1
    for shp in shps:
        try:
            g = gpd.read_file(shp)
            if len(g) == 0 or g.geometry.isnull().all():
                continue
            gt = g.geometry.iloc[0].geom_type
            if "Polygon" not in gt:
                continue
            if len(g) > best_n:
                best, best_n = shp, len(g)
        except Exception:
            pass
    return best

def clip_to_aoi(gdf: gpd.GeoDataFrame, aoi: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    if gdf.empty:
        return gdf
    if gdf.crs != aoi.crs:
        gdf = gdf.to_crs(aoi.crs)
    gdf = gdf[gdf.geometry.notnull()].copy()
    gdf["geometry"] = gdf.geometry.buffer(0)
    aoi2 = aoi.copy()
    aoi2["geometry"] = aoi2.geometry.buffer(0)
    return gpd.clip(gdf, aoi2)

# ----------------------------
# 1) AOI
# ----------------------------
if AOI_ZIP_LOCAL.exists():
    aoi_zip = AOI_ZIP_LOCAL
    print("✔ cached: nps_yell_tracts.zip")
else:
    aoi_zip = RAW / "nps_yell_tracts.zip"
    download_with_resume(AOI_ZIP_URL, aoi_zip)

aoi_dir = RAW / "aoi_unzipped"
unzip(aoi_zip, aoi_dir)

aoi_shps = find_shapefiles(aoi_dir)
if not aoi_shps:
    raise RuntimeError("No shapefile found inside AOI zip.")

aoi_shp = None
for cand in aoi_shps:
    if re.search(r"bound|boundary|yell", cand.name.lower()):
        aoi_shp = cand
        break
aoi_shp = aoi_shp or aoi_shps[0]

aoi = gpd.read_file(aoi_shp)
if len(aoi) > 1:
    aoi = aoi.dissolve()

if aoi.crs is None:
    raise RuntimeError("AOI has no CRS; cannot proceed.")

aoi_utm = aoi.to_crs(AOI_TARGET_EPSG)
aoi_utm = aoi_utm[aoi_utm.geometry.notnull()].copy()
aoi_utm["geometry"] = aoi_utm.geometry.buffer(0)
aoi_utm.to_file(AOI_GPKG, layer="aoi", driver="GPKG")
print("✔ AOI saved:", AOI_GPKG)

aoi_wgs84 = aoi_utm.to_crs(4326)
minx, miny, maxx, maxy = aoi_wgs84.total_bounds
print("AOI bounds (WGS84):", (minx, miny, maxx, maxy))

# ----------------------------
# 2) Thermal polygons (ScienceBase)
# ----------------------------
def sciencebase_download_url(item_id: str) -> str:
    item_url = f"https://www.sciencebase.gov/catalog/item/{item_id}?format=json"
    js = SESSION.get(item_url, timeout=90).json()
    for d in js.get("distributionLinks", []) or []:
        t = (d.get("type") or "").lower()
        title = (d.get("title") or "").lower()
        uri = d.get("uri") or d.get("url")
        if not uri:
            continue
        if t == "downloadlink" or "attached files" in title or "download attached files" in title:
            return uri
    return f"https://www.sciencebase.gov/catalog/file/get/{item_id}"

thermal_url = sciencebase_download_url(SCIENCEBASE_ITEM_ID)
print("Thermal download URL:", thermal_url)

thermal_zip = RAW / "thermal_sciencebase_attached_files.zip"
download_with_resume(thermal_url, thermal_zip)

thermal_dir = RAW / "thermal_unzipped"
unzip(thermal_zip, thermal_dir)

thermal_shps = find_shapefiles(thermal_dir)
if not thermal_shps:
    raise RuntimeError("No shapefile found inside thermal download zip.")

thermal_shp = None
for shp in thermal_shps:
    if "thermal_areas" in shp.name.lower():
        thermal_shp = shp
        break
thermal_shp = thermal_shp or pick_best_polygon_shp(thermal_shps) or thermal_shps[0]

thermal = gpd.read_file(thermal_shp)
if thermal.crs is None:
    thermal = thermal.set_crs(AOI_TARGET_EPSG)

thermal_utm = thermal.to_crs(AOI_TARGET_EPSG)
thermal_clip = clip_to_aoi(thermal_utm, aoi_utm)
thermal_clip.to_file(THERMAL_GPKG, layer="thermal_areas", driver="GPKG")
print("✔ Thermal polygons saved:", THERMAL_GPKG, "features:", len(thermal_clip))

# ----------------------------
# 3) Geology polygons (USGS OFR 99-174)
# ----------------------------
geology_zip = RAW / "ofr99174.zip"
download_with_resume(GEOLOGY_ZIP_URL, geology_zip)

geology_dir = RAW / "geology_ofr99174_unzipped"
unzip(geology_zip, geology_dir)

geo_shps = find_shapefiles(geology_dir)
if not geo_shps:
    raise RuntimeError("No shapefile found inside OFR 99-174 zip.")

preferred = None
for shp in geo_shps:
    if shp.name.lower() == "geol83pg.shp":
        preferred = shp
        break
geo_poly_shp = preferred or pick_best_polygon_shp(geo_shps) or geo_shps[0]
print("Geology chosen:", geo_poly_shp)

geol = gpd.read_file(geo_poly_shp)
prj_path = geo_poly_shp.with_suffix(".prj")

if geol.crs is None:
    if prj_path.exists():
        try:
            wkt = prj_path.read_text(errors="ignore")
            geol = geol.set_crs(wkt)
            print("✔ Geology CRS set from .prj")
        except Exception:
            geol = geol.set_crs(AOI_TARGET_EPSG)
            print("✔ Geology CRS assigned EPSG:", AOI_TARGET_EPSG)
    else:
        geol = geol.set_crs(AOI_TARGET_EPSG)
        print("✔ Geology CRS assigned EPSG:", AOI_TARGET_EPSG)

geol_utm = geol.to_crs(AOI_TARGET_EPSG)
geol_clip = clip_to_aoi(geol_utm, aoi_utm)

if GEOLOGY_GPKG.exists():
    GEOLOGY_GPKG.unlink()
geol_clip.to_file(GEOLOGY_GPKG, layer="geology", driver="GPKG")
print("✔ Geology saved:", GEOLOGY_GPKG, "features:", len(geol_clip))

# ----------------------------
# 4) GNIS / Geonames (ArcGIS REST)
# ----------------------------
def discover_gnis_layers(service_url: str):
    """
    Return list of (id, name, geometryType) for Feature Layers that are Point or Multipoint.
    Excludes group layers.
    """
    js = SESSION.get(f"{service_url}?f=pjson", timeout=90).json()
    layers = js.get("layers", []) or []
    out = []
    for lyr in layers:
        if lyr.get("subLayerIds") is not None:
            continue
        if lyr.get("type") != "Feature Layer":
            continue
        gt = lyr.get("geometryType")
        if gt in ("esriGeometryPoint", "esriGeometryMultipoint"):
            out.append((lyr.get("id"), lyr.get("name"), gt))
    return [(i, n, gt) for i, n, gt in out if i is not None and n is not None and gt is not None]

def arcgis_count(service_url: str, layer_id: int, bbox_wgs84):
    minx, miny, maxx, maxy = bbox_wgs84
    url = f"{service_url}/{layer_id}/query"
    params = {
        "f": "json",
        "where": "1=1",
        "returnCountOnly": "true",
        "geometryType": "esriGeometryEnvelope",
        "geometry": f"{minx},{miny},{maxx},{maxy}",
        "inSR": 4326,
        "spatialRel": "esriSpatialRelIntersects",
    }
    r = SESSION.get(url, params=params, timeout=120)
    r.raise_for_status()
    js = r.json()
    if "error" in js:
        raise RuntimeError(f"ArcGIS error (count) for layer {layer_id}: {js['error']}")
    return int(js.get("count", 0))

def arcgis_query_geojson(service_url: str, layer_id: int, bbox_wgs84, where="1=1", out_fields="*"):
    minx, miny, maxx, maxy = bbox_wgs84
    url = f"{service_url}/{layer_id}/query"
    page_size = 2000
    offset = 0
    feats = []
    while True:
        params = {
            "f": "geojson",
            "where": where,
            "outFields": out_fields,
            "returnGeometry": "true",
            "geometryType": "esriGeometryEnvelope",
            "geometry": f"{minx},{miny},{maxx},{maxy}",
            "inSR": 4326,
            "outSR": 4326,
            "spatialRel": "esriSpatialRelIntersects",
            "resultRecordCount": page_size,
            "resultOffset": offset,
        }
        r = SESSION.get(url, params=params, timeout=120)
        r.raise_for_status()
        js = r.json()
        if "error" in js:
            raise RuntimeError(f"ArcGIS error for layer {layer_id}: {js['error']}")
        new = js.get("features", [])
        feats.extend(new)
        exceeded = bool(js.get("exceededTransferLimit", False))
        if not exceeded and len(new) < page_size:
            break
        offset += page_size

    if not feats:
        return gpd.GeoDataFrame(geometry=[], crs="EPSG:4326")

    fc = {"type": "FeatureCollection", "features": feats}
    return gpd.GeoDataFrame.from_features(fc, crs="EPSG:4326")

layers = discover_gnis_layers(GEONAMES_SERVICE)
print(f"Discovered GNIS feature layers (point + multipoint): {len(layers)}")

bbox = (float(minx), float(miny), float(maxx), float(maxy))
layers_hit = []
frames = []

for i, name, gt in layers:
    try:
        cnt = arcgis_count(GEONAMES_SERVICE, i, bbox)
    except Exception as e:
        print(f"[warn] layer {i} count failed: {e}")
        continue
    if cnt <= 0:
        continue
    layers_hit.append((i, name, gt, cnt))
    print(f"✓ layer {i:>2} {gt:16s} count={cnt}  name={name}")

print("Layers intersecting AOI:", len(layers_hit))

# NOTE: The MapServer sometimes returns large bboxes; we trust bbox filter + clip-to-AOI later.
for i, name, gt, cnt in layers_hit:
    gdf = arcgis_query_geojson(GEONAMES_SERVICE, i, bbox)
    if len(gdf) == 0:
        continue
    gdf["src_layer_id"] = i
    gdf["src_layer_name"] = name
    frames.append(gdf)

if frames:
    gnis = pd.concat(frames, ignore_index=True)
    gnis = gpd.GeoDataFrame(gnis, geometry="geometry", crs="EPSG:4326")
else:
    gnis = gpd.GeoDataFrame(geometry=[], crs="EPSG:4326")

print("GNIS assembled (4326) features:", len(gnis))
if len(gnis):
    print("GNIS bounds (4326):", gnis.total_bounds)

gnis_utm = gnis.to_crs(AOI_TARGET_EPSG)
gnis_clip = clip_to_aoi(gnis_utm, aoi_utm)

gnis_clip.to_file(GNIS_GPKG, layer="geonames", driver="GPKG")
print("✔ GNIS/geonames saved:", GNIS_GPKG, "features:", len(gnis_clip))

# ----------------------------
# 5) DEM (USGS 3DEP via py3dep)
# ----------------------------
import py3dep

aoi_geom_wgs84 = aoi_wgs84.geometry.iloc[0]
dem = py3dep.get_dem(aoi_geom_wgs84, resolution=DEM_RES_M, crs=4326)

# Ensure CRS exists
if dem.rio.crs is None:
    dem = dem.rio.write_crs(5070, inplace=False)

dem_crs = dem.rio.crs
print("DEM CRS:", dem_crs)

aoi_dem = aoi_utm.to_crs(dem_crs)

# Bounds sanity-check before clip
dxmin, dymin, dxmax, dymax = dem.rio.bounds()
axmin, aymin, axmax, aymax = aoi_dem.total_bounds
intersects = not (dxmax < axmin or axmax < dxmin or dymax < aymin or aymax < dymin)

print("DEM bounds:", (dxmin, dymin, dxmax, dymax))
print("AOI bounds in DEM CRS:", (axmin, aymin, axmax, aymax))
if not intersects:
    raise RuntimeError("AOI does not intersect DEM bounds — DEM request likely returned an unexpected tile/CRS.")

dem_clip = dem.rio.clip(aoi_dem.geometry, aoi_dem.crs, drop=True)
dem_clip_utm = dem_clip.rio.reproject(AOI_TARGET_EPSG)
dem_clip_utm.rio.to_raster(DEM_TIF, compress="deflate")
print("✔ DEM saved:", DEM_TIF, "shape:", tuple(dem_clip_utm.shape))

# ----------------------------
# Manifest
# ----------------------------
manifest = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "target_epsg": AOI_TARGET_EPSG,
    "aoi": {
        "source_url": AOI_ZIP_URL,
        "aoi_shp_used": str(aoi_shp),
        "output_gpkg": str(AOI_GPKG),
        "aoi_bounds_wgs84": [float(minx), float(miny), float(maxx), float(maxy)]
    },
    "thermal": {
        "sciencebase_item_id": SCIENCEBASE_ITEM_ID,
        "download_url_used": thermal_url,
        "thermal_shp_used": str(thermal_shp),
        "output_gpkg": str(THERMAL_GPKG),
        "features": int(len(thermal_clip))
    },
    "geology": {
        "download_url": GEOLOGY_ZIP_URL,
        "geology_shp_used": str(geo_poly_shp),
        "prj_used_if_present": str(prj_path) if prj_path.exists() else None,
        "output_gpkg": str(GEOLOGY_GPKG),
        "features": int(len(geol_clip))
    },
    "gnis_geonames": {
        "service": GEONAMES_SERVICE,
        "queried_layers": [{"id": int(i), "name": n, "geometryType": gt, "count_bbox": int(c)} for i, n, gt, c in layers_hit],
        "output_gpkg": str(GNIS_GPKG),
        "features": int(len(gnis_clip))
    },
    "dem_3dep": {
        "provider": "USGS 3DEP via py3dep",
        "resolution_m": DEM_RES_M,
        "dem_crs": str(dem_crs),
        "output_tif": str(DEM_TIF)
    }
}
MANIFEST_JSON.write_text(json.dumps(manifest, indent=2))
print("✔ Wrote manifest:", MANIFEST_JSON)

print("\n=== OUTPUTS ===")
for p in sorted(PROC.glob("*")):
    print(p.name, f"({p.stat().st_size/1e6:.2f} MB)")
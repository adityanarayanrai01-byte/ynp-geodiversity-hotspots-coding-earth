#!/usr/bin/env python3
# ============================================================
# FIGURE 1 (Objective 1) — PUBLISHABLE VERSION
# - Panel A: continuous geodiversity index + single colorbar
# - Panel B: binary hotspots (top 10%) + north arrow
# - Legend + scale bar placed OUTSIDE the map area in a strip axis
#
# Output: Fig1_Obj1_Hotspots_FINAL_STRIP.png (+ .pdf)
#
# Usage:
#   python scripts/04_make_fig2_maps_scalebar_outside.py
#
# If your outputs are in a non-standard folder, set:
#   export YNP_OBJ1_DIR=/path/to/folder/containing/geodiversity_hotspots_obj1_slopeSD.gpkg
# ============================================================

import os, glob
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.patches import Patch
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize, ListedColormap

DEFAULT_OUT_NAME = "Fig1_Obj1_Hotspots_FINAL_STRIP"

def _find_first(patterns, roots):
    for root in roots:
        for pat in patterns:
            hits = glob.glob(os.path.join(root, "**", pat), recursive=True)
            if hits:
                hits = sorted(hits, key=lambda p: (len(p), p))
                return hits[0]
    return None

def main():
    roots = []
    env_dir = os.environ.get("YNP_OBJ1_DIR")
    if env_dir:
        roots.append(env_dir)

    roots += [
        os.getcwd(),
        "/content",
        "/content/yell_data", "/content/yell_data/processed", "/content/yell_data/processed_obj1",
        "/content/ynp_obj1_bundle",
        "/content/drive/MyDrive"
    ]

    gpkg = _find_first(
        ["geodiversity_hotspots_obj1_slopeSD.gpkg", "geodiversity_hotspots_obj1*.gpkg"],
        roots
    )
    if gpkg is None:
        raise FileNotFoundError(
            "Could not find Objective-1 output GPKG (geodiversity_hotspots_obj1_slopeSD.gpkg).\n"
            "Run scripts/00_run_all_obj1.py first, or set YNP_OBJ1_DIR."
        )

    out_dir = os.path.dirname(gpkg)
    aoi = _find_first(["aoi_yell.gpkg", "*aoi*.gpkg"], [out_dir, os.path.dirname(out_dir)] + roots)
    if aoi is None:
        raise FileNotFoundError("Could not find aoi_yell.gpkg. Ensure the input bundle is present.")

    g = gpd.read_file(gpkg, layer="obj1_grid_hotspots")
    a = gpd.read_file(aoi).to_crs(g.crs)

    fig_png = os.path.join(out_dir, f"{DEFAULT_OUT_NAME}.png")
    fig_pdf = os.path.join(out_dir, f"{DEFAULT_OUT_NAME}.pdf")

    fig = plt.figure(figsize=(14, 6.8))
    gs = fig.add_gridspec(
        nrows=2, ncols=3,
        height_ratios=[1.0, 0.16],
        width_ratios=[1.0, 1.0, 0.05],
        wspace=0.10, hspace=0.04
    )

    axA = fig.add_subplot(gs[0, 0])
    axB = fig.add_subplot(gs[0, 1])
    cax = fig.add_subplot(gs[:, 2])
    axB_strip = fig.add_subplot(gs[1, 1])
    axB_strip.axis("off")

    vmin = float(g["geodiv_index"].min())
    vmax = float(g["geodiv_index"].max())
    norm = Normalize(vmin=vmin, vmax=vmax)

    g.plot(column="geodiv_index", ax=axA, cmap="viridis", linewidth=0)
    a.boundary.plot(ax=axA, linewidth=0.6, color="0.2")
    axA.set_title("Panel A: Geodiversity Index (Obj1)", fontsize=12)

    sm = ScalarMappable(norm=norm, cmap="viridis")
    sm.set_array([])
    cb = fig.colorbar(sm, cax=cax)
    cb.set_label("Geodiversity index (0–1)", fontsize=10)

    hot_cmap = ListedColormap(["#F7F7F7", "#F1C40F"])
    g.plot(column="hotspot_p90", ax=axB, cmap=hot_cmap, linewidth=0)
    a.boundary.plot(ax=axB, linewidth=0.6, color="0.2")
    axB.set_title("Panel B: Hotspots (Top 10%)", fontsize=12)

    axB.annotate(
        "N",
        xy=(0.95, 0.92), xytext=(0.95, 0.82),
        xycoords="axes fraction", textcoords="axes fraction",
        ha="center", va="center", fontsize=16,
        arrowprops=dict(arrowstyle="-|>", lw=1.2)
    )

    for ax in [axA, axB]:
        ax.set_aspect("equal")
        ax.set_ylabel("Northing (m, UTM Zone 12N)", fontsize=9)
        ax.tick_params(labelsize=8)
        ax.ticklabel_format(style="plain", axis="both", useOffset=False)
        ax.xaxis.set_major_formatter(mticker.StrMethodFormatter("{x:,.0f}".replace(",", "")))
        ax.yaxis.set_major_formatter(mticker.StrMethodFormatter("{x:,.0f}".replace(",", "")))

    axA.set_xlabel("Easting (m, UTM Zone 12N)", fontsize=9)
    axB.set_xlabel("")

    minx, miny, maxx, maxy = a.total_bounds
    pad = 2000
    for ax in [axA, axB]:
        ax.set_xlim(minx - pad, maxx + pad)
        ax.set_ylim(miny - pad, maxy + pad)

    legend_handles = [
        Patch(facecolor="#F7F7F7", edgecolor="0.6", label="Not hotspot"),
        Patch(facecolor="#F1C40F", edgecolor="0.6", label="Hotspot (≥ p90)"),
    ]
    axB_strip.legend(
        handles=legend_handles,
        loc="center left",
        bbox_to_anchor=(0.02, 0.5),
        ncol=2,
        frameon=True,
        fontsize=9
    )

    bar_km = 20
    x0, x1 = 0.68, 0.98
    y = 0.62
    axB_strip.plot([x0, x1], [y, y], lw=5, color="k",
                   solid_capstyle="butt", transform=axB_strip.transAxes)
    axB_strip.text((x0 + x1) / 2, 0.22, f"{bar_km} km",
                   ha="center", va="center", fontsize=10,
                   transform=axB_strip.transAxes)

    plt.savefig(fig_png, dpi=600, bbox_inches="tight")
    plt.savefig(fig_pdf, bbox_inches="tight")
    plt.close(fig)

    print("✅ Wrote:", fig_png)
    print("✅ Wrote:", fig_pdf)

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# ============================================================
# Export per-cell CSV with WGS84 centroids from Obj1 output GPKG
# Inputs:
#   processed_obj1/geodiversity_hotspots_obj1_slopeSD.gpkg (layer: obj1_grid_hotspots)
# Outputs:
#   processed_obj1/obj1_cells_with_centroids_wgs84.csv
# ============================================================

import os, glob
from pathlib import Path
import geopandas as gpd
import pandas as pd

def find_first(patterns, roots):
    for root in roots:
        root = str(root)
        for pat in patterns:
            hits = glob.glob(os.path.join(root, "**", pat), recursive=True)
            if hits:
                hits = sorted(hits, key=lambda p: (len(p), p))
                return hits[0]
    return None

HERE = Path(__file__).resolve()
BUNDLE_ROOT = HERE.parents[1]
roots = [
    Path("/content/yell_data/processed_obj1"),
    BUNDLE_ROOT / "processed_obj1",
    BUNDLE_ROOT,
    Path.cwd(),
]

gpkg = find_first(["geodiversity_hotspots_obj1_slopeSD.gpkg"], roots)
if gpkg is None:
    raise FileNotFoundError("Could not find geodiversity_hotspots_obj1_slopeSD.gpkg. Run Obj1 build first.")

gdf = gpd.read_file(gpkg, layer="obj1_grid_hotspots")
cent = gdf.geometry.centroid
cent_wgs84 = gpd.GeoSeries(cent, crs=gdf.crs).to_crs(4326)

df = gdf.drop(columns=["geometry"]).copy()
df["centroid_lon"] = cent_wgs84.x.values
df["centroid_lat"] = cent_wgs84.y.values

out_dir = Path(gpkg).parent
out_csv = out_dir / "obj1_cells_with_centroids_wgs84.csv"
df.to_csv(out_csv, index=False)

print("✅ Wrote:", out_csv)

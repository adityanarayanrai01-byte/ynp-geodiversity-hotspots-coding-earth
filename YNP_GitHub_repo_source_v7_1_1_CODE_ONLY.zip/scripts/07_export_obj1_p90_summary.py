#!/usr/bin/env python3
# ============================================================
# Export p90 threshold + hotspot count from Obj1 output
# Inputs:
#   processed_obj1/geodiversity_hotspots_obj1_slopeSD.gpkg (layer: obj1_grid_hotspots)
# Outputs:
#   processed_obj1/obj1_hotspot_p90_summary.csv
# ============================================================

import os, glob
from pathlib import Path
import geopandas as gpd
import pandas as pd

def find_first(patterns, roots):
    for root in roots:
        root = str(root)
        for pat in patterns:
            hits = glob.glob(os.path.join(root, "**", pat), recursive=True)
            if hits:
                hits = sorted(hits, key=lambda p: (len(p), p))
                return hits[0]
    return None

HERE = Path(__file__).resolve()
BUNDLE_ROOT = HERE.parents[1]
roots = [
    Path("/content/yell_data/processed_obj1"),
    BUNDLE_ROOT / "processed_obj1",
    BUNDLE_ROOT,
    Path.cwd(),
]

gpkg = find_first(["geodiversity_hotspots_obj1_slopeSD.gpkg"], roots)
if gpkg is None:
    raise FileNotFoundError("Could not find geodiversity_hotspots_obj1_slopeSD.gpkg. Run Obj1 build first.")

gdf = gpd.read_file(gpkg, layer="obj1_grid_hotspots")
if "geodiv_index" not in gdf.columns:
    raise ValueError("Missing geodiv_index column in output layer.")

p90 = float(gdf["geodiv_index"].quantile(0.90))
hotspot = (gdf["geodiv_index"] >= p90).astype(int)

out_dir = Path(gpkg).parent
out_csv = out_dir / "obj1_hotspot_p90_summary.csv"
pd.DataFrame([{
    "p90_threshold_geodiv_index": p90,
    "hotspot_count": int(hotspot.sum()),
    "grid_cells_total": int(len(gdf)),
    "hotspot_share": float(hotspot.mean())
}]).to_csv(out_csv, index=False)

print("Hotspot threshold (p90):", p90)
print("Hotspot count:", int(hotspot.sum()), "of", len(gdf))
print("✅ Wrote:", out_csv)

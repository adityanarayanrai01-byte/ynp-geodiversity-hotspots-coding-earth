# What is (not) in this GitHub repository

This repository is a **code + documentation mirror** of the Yellowstone Objective‑1 replication bundle.

To keep the GitHub repo lightweight and legally clean, **large processed inputs and rasters are NOT included here**.
Please obtain the full, self‑contained replication bundle (data + scripts + manifests + checksums) from Zenodo:

- DOI: 10.5281/zenodo.18519435
- Record: https://zenodo.org/records/18519435

Reproduction (recommended):
1) Download the Zenodo ZIP
2) Unzip locally
3) Run: `python scripts/00_run_all_obj1.py`

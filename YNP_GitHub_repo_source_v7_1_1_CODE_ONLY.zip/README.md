# Yellowstone Coding Earth — Reproducible Geodiversity Hotspot Workflow (Objective 1)

**Version:** v7.1.1  
**Last updated:** 2026-02-08

This repository-style ZIP is a **self-contained replication package** for **Objective 1** of our Yellowstone case study.
It includes the **processed input datasets**, **Python scripts**, **provenance manifests**, and **checksums** needed to reproduce the published outputs **offline** (no internet required during rerun).

## What this package reproduces
- A **1 km × 1 km** analysis grid clipped to the Yellowstone National Park AOI
- Per-cell metrics:
  - `thermal_area_m2` (area of thermal polygons intersecting each cell)
  - `geology_richness` (unique geologic units per cell; sliver control optional)
  - `slope_sd_deg` (standard deviation of slope in degrees from a 30 m DEM)
- A composite **Geodiversity Index (GDI)** (equal-weighted mean of min–max normalized components)
- **Hotspots**: cells where `GDI ≥ p90` (top 10%)
- **Figure 1**: two-panel map (GDI + hotspot mask), generated as:
  - `docs/figures/Fig1_Obj1_Hotspots_FINAL_STRIP.png` (+ optional PDF)

## Precomputed outputs included
For convenience (and to support *read-only* reuse without rerunning the workflow), this Zenodo-ready bundle **includes the Objective 1 outputs** in `processed_obj1/`:
- `geodiversity_hotspots_obj1_slopeSD.gpkg` (layer `obj1_grid_hotspots`)
- `hotspot_summary_obj1_slopeSD.csv` (per-cell attributes; no geometry)
- `obj1_cells_with_centroids_wgs84.csv` (per-cell attributes + WGS84 centroid lon/lat)
- `obj1_hotspot_p90_summary.csv` (p90 threshold + hotspot count)

## Quick start (offline rerun)
From the ZIP root:

```bash
python scripts/00_run_all_obj1.py
```

This stages inputs into a working folder and runs the full Objective 1 workflow, ending with **Figure 1**.

### Manual run order (if you prefer)
```bash
python scripts/02_core_build_obj1_grid_thermal_geology_slopeSD.py
python scripts/03_upgradeA_slopeSD_index_and_hotspots.py
python scripts/04_make_fig1_maps_scalebar_outside.py
```

## Expected outputs (names may differ if you change parameters)
- GeoPackage outputs with per-cell attributes + hotspot flag
- Summary CSV diagnostics (p90 threshold, counts, ranges)
- `docs/figures/Fig1_Obj1_Hotspots_FINAL_STRIP.png`

## Integrity checks
- `INPUTS_SHA256SUMS.txt` contains SHA-256 checksums for the **bundled inputs + manifests**.
- `SHA256SUMS_ALL.txt` (added in v7.1) contains SHA-256 checksums for **all files in this package**.

## Software environment
Two options are provided:
- `requirements.txt` (pip)
- `environment.yml` (conda-forge)

## Licensing and third‑party data
- **Code:** released under the MIT License (see `LICENSE`).
- **Data:** input datasets originate from **USGS** and **NPS** sources; their original terms apply. See the provenance manifests:
  - `sources_manifest.json`
  - `sources_manifest_with_scripts.json`

## How to cite
See `CITATION.cff`. If you reserve a Zenodo DOI, add it to the Zenodo record metadata (and optionally update `CITATION.cff` in the next release).

## CSV exports
After you have a `processed_obj1/geodiversity_hotspots_obj1_slopeSD.gpkg`, you can (re)generate the extra CSVs with:

```bash
python scripts/06_export_obj1_cells_csv.py
python scripts/07_export_obj1_p90_summary.py
```
---

## GitHub repository note

This GitHub repository contains **code and documentation only** (no large rasters / packaged inputs).
For the complete, citable, self‑contained replication bundle used for peer review (including processed inputs where licensing permits, manifests, and integrity checksums), use Zenodo:

- DOI: 10.5281/zenodo.18519435
- Record: https://zenodo.org/records/18519435

If you fork this repository, please keep the Zenodo DOI in your citations so readers can obtain the exact archived data+code release.

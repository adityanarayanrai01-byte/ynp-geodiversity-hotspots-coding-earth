# How to publish this repo to GitHub

1) Create a new public repository on GitHub (no files).
2) Download and unzip this "CODE_ONLY" bundle.
3) In the unzipped folder:

```bash
git init
git add .
git commit -m "Initial commit (code + docs mirror of Zenodo bundle)"
git branch -M main
git remote add origin <YOUR_GITHUB_REPO_URL.git>
git push -u origin main
```

Recommended:
- Add a GitHub "Release" tag matching VERSION.txt (e.g., v7.1.1)
- In the release notes, paste the Zenodo DOI/record link.

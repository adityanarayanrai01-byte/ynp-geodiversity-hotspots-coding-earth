# Yellowstone Coding Earth — Procured Data + Scripts (Reviewer Bundle)

This bundle contains **all required inputs** (AOI, DEM, thermal polygons, geology polygons, GNIS points) **plus scripts**
to reproduce **Objective 1** outputs and the **publication-ready Figure 1**.

## What’s guaranteed reproducible (matches the verified run)
- 1 km grid clipped to the Yellowstone AOI
- Per-cell metrics:
  - `thermal_area_m2`
  - `geology_richness` (unique geology units; default field `PTYPE_GEN`)
  - `slope_sd_deg` (SD of slope in degrees from 30 m DEM)
- Normalization: min–max to [0,1] for each component (`n_thermal`, `n_geol`, `n_slopeSD`)
- Composite index: `geodiv_index` = mean of normalized components (equal weights)
- Hotspots: `hotspot_p90` = 1 if `geodiv_index` ≥ 90th percentile

## Scripts
- `scripts/00_run_all_obj1.py`
  - **No internet required**. Stages bundled inputs into `/content/yell_data/processed`,
    runs the core build, generates Figure 1, and produces an output ZIP for reviewers.

- `scripts/02_core_build_obj1_grid_thermal_geology_slopeSD.py`
  - Creates `processed_obj1/geodiversity_hotspots_obj1_slopeSD.gpkg` (layer `obj1_grid_hotspots`)
  - Writes `processed_obj1/hotspot_summary_obj1_slopeSD.csv`

- `scripts/04_make_fig1_maps_scalebar_outside.py`
  - Generates Figure 1 with **legend + scale bar outside the map area** (strip below Panel B)

## Typical Colab usage
1) Upload this ZIP to Colab and unzip (any folder is fine)
2) Run:
```bash
python scripts/00_run_all_obj1.py
```

Outputs are written to:
- `/content/yell_data/processed_obj1/` (primary)
- `./processed_obj1/` (mirror next to the unzipped bundle)

## Procurement (optional)
- The original procurement workflow is documented in `scripts/01_procure_yellowstone_inputs.py`.
- It is **not required** to reproduce results in this ZIP. See `docs/PROCUREMENT_NOTES.md` and `INPUTS_SHA256SUMS.txt`.

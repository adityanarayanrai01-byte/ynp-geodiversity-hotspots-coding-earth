# Procurement notes (transparency; not required for reproduction)

This reviewer bundle is **self-contained**: all inputs used to produce the manuscript results are included in the ZIP.
Reproducing Objective 1 and Figure 1 **does not require downloading anything**.

## Why a procurement script is still included
`scripts/01_procure_yellowstone_inputs.py` documents how the input datasets were originally assembled (sources, clipping, CRS).
It is included for **provenance and future re-assembly**, not as a requirement for review.

Because upstream hosts may change file paths, versions, or require internet access, procurement is **best-effort** and may not be
deterministic across time. The authoritative inputs for reproduction are the files included in this ZIP (see `INPUTS_SHA256SUMS.txt`).

## How to reproduce results (offline)
Run:
- `python scripts/00_run_all_obj1.py`

or directly:
- `python scripts/02_core_build_obj1_grid_thermal_geology_slopeSD.py`
- `python scripts/04_make_fig2_maps_scalebar_outside.py`

## Integrity verification
To verify you are using the same inputs as the authors, compare SHA256 hashes in `INPUTS_SHA256SUMS.txt`.

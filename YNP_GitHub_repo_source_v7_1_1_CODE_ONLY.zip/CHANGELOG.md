# Changelog
## v7.1.1 — 2026-02-08
- Added precomputed Objective 1 outputs under `processed_obj1/`, including per-cell CSV tables and a p90 threshold summary.
- Added `scripts/05_build_obj1_outputs_fast.py` (optional fast builder) and CSV export utilities (`scripts/06_*`, `scripts/07_*`).
- Improved cross-environment portability of Obj1 scripts (GeoPackage layer detection via Fiona; robust output-path fallback when `/content` is not writable).


## v7.1 — 2026-02-07
- Renamed publication output from **Figure 2** to **Figure 1** for manuscript consistency.
- Added Zenodo-ready root files: `README.md`, `LICENSE`, `CITATION.cff`, `requirements.txt`, `environment.yml`.
- Added `SHA256SUMS_ALL.txt` for integrity verification of the full package.
- Kept a backward-compatible wrapper script: `scripts/04_make_fig2_maps_scalebar_outside.py` → calls the Figure 1 generator.
